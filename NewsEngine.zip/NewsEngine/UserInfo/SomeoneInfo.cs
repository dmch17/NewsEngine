﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsEngine.UserInfo
{
    public struct SomeoneInfo
    {
        public String Name;
        public int Age;
        public DateTime DateOfBirth;
    }
}